// 入口文件，在项目中，就像一个清单一样


// 引入核心组件
import "./pages/App"

// 引入初始化样式
import "normalize.css"

// 引入全局样式
import "./assets/styles/core.less"




