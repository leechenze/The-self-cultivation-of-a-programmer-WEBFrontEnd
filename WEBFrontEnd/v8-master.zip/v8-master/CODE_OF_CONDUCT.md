# V8 Code of Conduct

As part of the Chromium team, the V8 team is committed to preserving and
fostering a diverse, welcoming community. To this end, the [Chromium Code of
Conduct](https://chromium.googlesource.com/chromium/src/+/master/CODE_OF_CONDUCT.md)
applies to our repos and organizations, mailing lists, blog content, and any
other Chromium-supported communication group, as well as any private
communication initiated in the context of these spaces.
