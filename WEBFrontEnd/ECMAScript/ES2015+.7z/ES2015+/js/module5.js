console.log('module5 模块加载了');


// import a from './module4.js'
// console.log(a);



// let [a,b] = [10,20];
// let show = () => {
//     return 'show执行了';
// }

// let sum = () => {
//     return a+b;
// }


// class Person{
//     constructor(name,age){
//         this.name = name,
//         this.age = age
//     }
//     showName(){
//         return `我的名字是${this.name}`;
//     }
// }

// export default{
//     Person,
// }
// export {
//     sum,
//     show,
//     a,
//     b
// }
