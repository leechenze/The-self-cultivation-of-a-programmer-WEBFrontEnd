console.log('module4 模块加载了');

// const [a,b,c] = [10,20,30];

// export {
//     b,c
// }

// export default {
//     a
// }

// let [a,b,c] = [10,20,30];
// export default{
//     a,b,c
// } 


