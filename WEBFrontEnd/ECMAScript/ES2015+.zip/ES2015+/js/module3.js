console.log('module3 模块加载了');

const a = 12;
const b = 10;
const c = 20;

export {
    a as aa,
    b as bb,
    c as cc,
}