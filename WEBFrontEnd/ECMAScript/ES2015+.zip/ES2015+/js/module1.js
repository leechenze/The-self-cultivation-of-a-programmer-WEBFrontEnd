console.log('module1 模块加载了');
export const a = 12;





