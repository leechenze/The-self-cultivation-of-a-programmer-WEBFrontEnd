console.log('module6 模块加载了');

// let a = 12,b = 5;
// setTimeout(() => {
//     a = 9999;
// },2000);

// // export default a;
// export default { 
//     a,
//     b
// }

// let a = 12,b = 5;
// setTimeout(() => {
//     a = 9999;
// },2000);

// export{
//     a,
//     b
// }

































