'use strict';
// We've experienced a regression where the module loader stats a bunch of
// directories on require() even if it's been called before. The require()
// should caching the request.
const common = require('../common');
const fs = require('fs');
const assert = require('assert');

let counter = 0;

// Switch out the two stat implementations so that they increase a counter
// each time they are called.

const _statSync = fs.statSync;
const _stat = fs.stat;

fs.statSync = function() {
  counter++;
  return _statSync.apply(this, arguments);
};

fs.stat = function() {
  counter++;
  return _stat.apply(this, arguments);
};

// Load the module 'a' and 'http' once. It should become cached.
require(common.fixturesDir + '/a');
require('../fixtures/a.js');
require('./../fixtures/a.js');
require('http');

console.log('counterBefore = %d', counter);
const counterBefore = counter;

// Now load the module a bunch of times with equivalent paths.
// stat should not be called.
for (let i = 0; i < 100; i++) {
  require(common.fixturesDir + '/a');
  require('../fixtures/a.js');
  require('./../fixtures/a.js');
}

// Do the same with a built-in module
for (let i = 0; i < 100; i++) {
  require('http');
}

console.log('counterAfter = %d', counter);
const counterAfter = counter;

assert.strictEqual(counterBefore, counterAfter);
